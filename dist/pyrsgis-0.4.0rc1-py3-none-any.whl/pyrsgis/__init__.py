"""
pyrsgis - Python for Remote Sensing and GIS
author: pratkrt<at>gmail.com
Compatible with Python versions 3+
"""

name = 'pyrsgis'
__version__ = "0.4.0rc1"


#Importing all functions from beta
from .beta import *
