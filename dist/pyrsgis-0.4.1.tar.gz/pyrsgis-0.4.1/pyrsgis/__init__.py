"""
pyrsgis - Python for Remote Sensing and GIS
author: pratkrt<at>gmail.com
Compatible with Python versions 3+
"""

name = 'pyrsgis'
__version__ = "0.4.1"
doc_address = r'https://pyrsgis.readthedocs.io/en/master/'

#Importing all functions from beta
from .beta import *
